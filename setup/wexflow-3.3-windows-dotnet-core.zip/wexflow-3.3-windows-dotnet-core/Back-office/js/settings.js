﻿Settings = {
    Uri: "http://localhost:8000/wexflow/"
};