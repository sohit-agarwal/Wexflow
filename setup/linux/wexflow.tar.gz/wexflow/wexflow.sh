#!/bin/sh

/opt/wexflow/Wexflow.Clients.Eto.Manager.exe
