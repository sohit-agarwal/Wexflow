#!/bin/sh

mono Wexflow.Clients.Eto.Manager.exe